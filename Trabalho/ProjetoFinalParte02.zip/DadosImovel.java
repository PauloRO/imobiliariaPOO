import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class DadosImovel {

    private ArrayList<Imovel> vetImoveis = new ArrayList<Imovel>();

    public void cadastrar(Imovel imovel) {
        if (this.vetImoveis.add(imovel)) {
            System.out.println("Imovel cadastrado no sistema!");
            System.out.println("Total de imoveis inseridos: " + this.vetImoveis.size() + "\n");
        } else
            System.out.println("Erro ao cadastrar!");
    }

    public void listar() {
        for (Imovel imovel : this.vetImoveis) {
            System.out.println(imovel + "\n");
        }
    }

    public Imovel buscar(int codigoImovel) {
        Imovel resultado = null;
        for (Imovel imovel : this.vetImoveis) {
            if (imovel.getCodigoImovel() == codigoImovel) {
                resultado = imovel;
                System.out.println(resultado);
                break;
            } else{
                System.out.println("Imóvel não encontrado!");
                break;
            }
        }
        return resultado;
    }

    public boolean excluir(int codigoImovel) {
        Imovel imovel = this.buscar(codigoImovel);
        if (imovel != null) {
            this.vetImoveis.remove(imovel);
            return true;
        }
        return false;
    }

    public void salvaContatosBin() {
        FileOutputStream fileWriter = null;
        ObjectOutputStream objWriter = null;

        try {
            fileWriter = new FileOutputStream("ImoveisBin");
            objWriter = new ObjectOutputStream(fileWriter);
            objWriter.writeObject(this.vetImoveis.size() + "\n");
            for (Imovel imovel : this.vetImoveis) {
                objWriter.writeObject(imovel.toString() + "\n");
            }
            System.out.println("Arquivo: \"ImoveisBin\" salvo com sucesso!");
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (fileWriter != null)
                    fileWriter.close();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

}

