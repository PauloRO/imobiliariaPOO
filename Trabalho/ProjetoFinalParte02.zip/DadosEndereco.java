import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class DadosEndereco {
	private ArrayList<Endereco> vetEnderecos = new ArrayList<Endereco>();

	public void cadastrar(Endereco endereco) {
		if (this.vetEnderecos.add(endereco)) {
			System.out.println("Endereço cadastrado no sistema!");
			System.out.println("Total de endereços inseridos: " + this.vetEnderecos.size() + "\n");
		} else
			System.out.println("Erro ao cadastrar!");
	}

	public void listar() {
		for (Endereco endereco : this.vetEnderecos) {
			System.out.println(endereco + "\n");
		}
	}

	public Endereco buscar(String rua, int numero) {
		Endereco resultado = null;
		for (Endereco endereco : this.vetEnderecos) {
			if (endereco.getRua().equals(rua) && (endereco.getNumero() == numero)) {
				resultado = endereco;
				System.out.println(resultado);
				break;
			} else{
				System.out.println("Endereço não encontrado!");
				break;
			}
		}
		return resultado;
	}

	public boolean excluir(String rua, int numero) {
		Endereco endereco = this.buscar(rua, numero);
		if (endereco != null) {
			this.vetEnderecos.remove(endereco);
			return true;
		}
		return false;
	}

	public void salvaContatosBin() {
		FileOutputStream fileWriter = null;
		ObjectOutputStream objWriter = null;

		try {
			fileWriter = new FileOutputStream("EnderecosBin");
			objWriter = new ObjectOutputStream(fileWriter);
			objWriter.writeObject(this.vetEnderecos.size() + "\n");
			for (Endereco endereco : this.vetEnderecos) {
				objWriter.writeObject(endereco.toString() + "\n");
			}
			System.out.println("Arquivo: \"EnderecosBin\" salvo com sucesso!");
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if (fileWriter != null)
					fileWriter.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
