public interface Pagamentos {

    // Pagamentos que devem ser realizados pelas salas comerciais

    float pagarSistemaVigilancia();
    float pagarTaxaManutencao();
}
