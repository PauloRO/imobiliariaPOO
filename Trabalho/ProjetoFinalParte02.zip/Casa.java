import java.time.LocalDate;

public class Casa extends Residencial{

	private boolean condominio;
	private boolean piscina;

	public Casa() {
	}

	public Casa(int codigoImovel, byte disponibilidade, String bairro, String descricao, boolean condominio) {
		super(codigoImovel, disponibilidade, bairro, descricao);
		setCondominio(condominio);
	}

	public Casa(int codigoImovel, LocalDate dataConstrucao, byte disponibilidade, float areaMetrosQuadrados, String bairro,
				float valorSugerido, float valorReal, float taxaImobiliaria, LocalDate data, boolean venda, boolean aluguel,
				Proprietario[] proprietarios, Endereco endereco, int quantidadeQuartos, int quantidadeSuites, int quantidadeSalasEstar,
				int quantidadeSalasJantar, int numeroVagasGaragem, boolean possuiArmarioEmbutido, String descricao,
				boolean condominio, boolean piscina) {

		super(codigoImovel, dataConstrucao, disponibilidade, areaMetrosQuadrados, bairro, valorSugerido, valorReal,
				taxaImobiliaria, data, venda, aluguel, proprietarios, endereco, quantidadeQuartos, quantidadeSuites, quantidadeSalasEstar,
				quantidadeSalasJantar, numeroVagasGaragem, possuiArmarioEmbutido, descricao);

		setCondominio(condominio);
		setPiscina(piscina);
	}

	public boolean isCondominio() {
		return condominio;
	}

	public boolean setCondominio(boolean condominio) {
		if (condominio != true && condominio != false)
			return false;

		this.condominio = condominio;
		return true;
	}

	public boolean isPiscina() {
		return piscina;
	}

	public boolean setPiscina(boolean piscina) {
		if (piscina != true && piscina != false)
			return false;

		this.piscina = piscina;
		return true;
	}

}
